﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.PageObjects;
namespace UnitTestProject23
{
    class BrowserNavigation
    {
        public static IWebDriver driver;
        public static void BrowserUrl(string url)
        {
            driver = new FirefoxDriver();
            driver.Navigate().GoToUrl(url);
            driver.Manage().Window.Maximize();
            driver.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds(10));
        }

        public static void cleanup()
        {
            driver.Quit();
        }
       
    }
}
