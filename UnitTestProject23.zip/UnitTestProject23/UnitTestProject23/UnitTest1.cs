﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
namespace UnitTestProject23
{
    [TestClass]
    public class UnitTest1 
    {
        [TestMethod]
        public void TestMethod1()
        {
            BrowserNavigation.BrowserUrl("http://geico.com");
            Console.WriteLine("Browser is opened.....");
            SetMethod.EnterText(BrowserNavigation.driver, ".//*[@id='zip']", "90210", "XPath");
            string getvalue=GetMethod.GetText(BrowserNavigation.driver, ".//*[@id='zip']", "XPath");
            Console.WriteLine("Values Enter in ZipCODE...."+getvalue);
            
            SetMethod.ClickonAction(BrowserNavigation.driver, ".//*[@id='submitButton']", "XPath");

            Console.WriteLine("===================== Home page is successfull and Move to Customer Page ============================================");


            //Customer Information

            SetMethod.EnterText(BrowserNavigation.driver, ".//*[@id='CustomerForm:firstName']", "Value", "XPath");
            SetMethod.EnterText(BrowserNavigation.driver, ".//*[@id='CustomerForm:lastName']", "Momentum", "XPath");
            SetMethod.EnterText(BrowserNavigation.driver, ".//*[@id='CustomerForm:customerMailingAddress']", "Hyderabad", "XPath");
            SetMethod.EnterText(BrowserNavigation.driver, ".//*[@id='CustomerForm:unitNumber']", "56", "XPath");
            SetMethod.EnterText(BrowserNavigation.driver, ".//*[@id='CustomerForm:birthMonth']", "08", "XPath");
            SetMethod.EnterText(BrowserNavigation.driver, ".//*[@id='CustomerForm:birthDay']", "08", "XPath");
            SetMethod.EnterText(BrowserNavigation.driver, ".//*[@id='CustomerForm:birthYear']", "1995", "XPath");
            SetMethod.ClickonAction(BrowserNavigation.driver, ".//*[@id='CustomerForm:fqUnmarriedDriver:0']", "XPath");
            SetMethod.ClickonAction(BrowserNavigation.driver, ".//*[@id='CustomerForm:continueBtn']", "XPath");

            //Add Vehicle Information

            SetMethod.SelectListValues(BrowserNavigation.driver, ".//*[@id='VehicleForm:year']", "2010", "XPath");
            SetMethod.SelectListValues(BrowserNavigation.driver, ".//*[@id='VehicleForm:make']", "2010", "XPath");

        /*    SetMethod.SelectListValues(BrowserNavigation.driver, ".//*[@id='VehicleForm:model']", "2010", "XPath");
            SetMethod.SelectListValues(BrowserNavigation.driver, ".//*[@id='VehicleForm:hybrid:0']", "2010", "XPath");
            SetMethod.SelectListValues(BrowserNavigation.driver, ".//*[@id='VehicleForm:ownership']", "2010", "XPath");

            SetMethod.SelectListValues(BrowserNavigation.driver, ".//*[@id='VehicleForm:otherBusiness']", "2010", "XPath");*/






            /*  SetMethod.SelectListValues(BrowserNavigation.driver, ".//*[@id='homepage_manage_select']", "Condo", "XPath");
              string listvalue=GetMethod.GetvaluefromDDL(BrowserNavigation.driver, ".//*[@id='homepage_manage_select']", "XPath");
              Console.WriteLine("u have selected from ddp"+listvalue);*/
        }
    }
}
