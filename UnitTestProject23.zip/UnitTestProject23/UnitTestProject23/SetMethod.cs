﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Support.PageObjects;
namespace UnitTestProject23
{
    class SetMethod
    {
        //Entering Text in WebEdit 
        public static void EnterText(IWebDriver driver, string Elements, string Value, string ElementType)
        {
            if (ElementType == "Id") { driver.FindElement(By.Id(Elements)).SendKeys(Value); }
            if (ElementType == "Name") { driver.FindElement(By.Name(Elements)).SendKeys(Value); }
            if (ElementType == "XPath") { driver.FindElement(By.XPath(Elements)).SendKeys(Value); }  


        }


        //Click into a button,link,checkbox,Radiobutton


        public static void ClickonAction(IWebDriver driver, string Elements, string ElementType)
        {
            if (ElementType == "Id") { driver.FindElement(By.Id(Elements)).Click(); }
         
            if (ElementType == "Name") { driver.FindElement(By.Name(Elements)).Click();}

            if (ElementType == "XPath") { driver.FindElement(By.XPath(Elements)).Click(); }
         
        }

        public static void SelectListValues(IWebDriver driver, string Elements, string Value, string ElementType)
        {
            if (ElementType == "Id")
            {
                new SelectElement(driver.FindElement(By.Id(Elements))).SelectByText(Value);
            }
            if (ElementType == "Name") { new SelectElement(driver.FindElement(By.Name(Elements))).SelectByText(Value); }
            if (ElementType == "XPath") { new SelectElement(driver.FindElement(By.XPath(Elements))).SelectByText(Value); } 
        }


    }
}
